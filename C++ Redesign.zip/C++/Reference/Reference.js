document.getElementById("searchInput").addEventListener("keyup", function () {
    let input = this.value.toLowerCase();
    let dropdown = document.getElementById("dropdownList");
    let items = dropdown.getElementsByTagName("li");

    let hasResults = false;

    for (let i = 0; i < items.length; i++) {
        let text = items[i].textContent.toLowerCase();
        if (text.includes(input)) {
            items[i].style.display = "block";
            hasResults = true;
        } else {
            items[i].style.display = "none";
        }
    }

    // Show dropdown only if there are results
    if (hasResults && input.length > 0) {
        dropdown.classList.add("show-dropdown");
    } else {
        dropdown.classList.remove("show-dropdown");
    }
});

// Hide dropdown when clicking outside
document.addEventListener("click", function (event) {
    let searchBox = document.querySelector(".search-container");
    let dropdown = document.getElementById("dropdownList");

    if (!searchBox.contains(event.target)) {
        dropdown.classList.remove("show-dropdown");
    }
});




document.addEventListener("DOMContentLoaded", function () {
    const radioButtons = document.querySelectorAll('.options input[type="radio"]');
    const sections = document.querySelectorAll('.section');
  
    // Function to show/hide sections based on the selected option
    function updateSections(selectedSection) {
      sections.forEach((section) => {
        if (selectedSection === "all") {
          // Show all sections
          section.classList.add("active");
        } else if (section.id === selectedSection) {
          // Show only the selected section
          section.classList.add("active");
        } else {
          // Hide other sections
          section.classList.remove("active");
        }
      });
    }
  
    // Add event listeners to radio buttons
    radioButtons.forEach((radio) => {
      radio.addEventListener("change", function () {
        const selectedSection = this.getAttribute("data-section");
        updateSections(selectedSection);
      });
    });
  
    // Trigger the "All" option by default on page load
    const allRadio = document.getElementById("all");
    if (allRadio) {
      allRadio.checked = true; // Ensure "All" is selected
      updateSections("all"); // Show all sections
    }
  });