    // Category Filtering
    const filterButtons = document.querySelectorAll('.filter-button');
    const articleCards = document.querySelectorAll('.article-card');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to the clicked button
            button.classList.add('active');

            // Get the category to filter
            const category = button.getAttribute('data-category');

            // Show/hide articles based on the selected category
            articleCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                if (category === 'all' || cardCategory === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });



    document.getElementById("searchInput").addEventListener("keyup", function () {
        let input = this.value.toLowerCase();
        let dropdown = document.getElementById("dropdownList");
        let items = dropdown.getElementsByTagName("li");
    
        let hasResults = false;
    
        for (let i = 0; i < items.length; i++) {
            let text = items[i].textContent.toLowerCase();
            if (text.includes(input)) {
                items[i].style.display = "block";
                hasResults = true;
            } else {
                items[i].style.display = "none";
            }
        }
    
        // Show dropdown only if there are results
        if (hasResults && input.length > 0) {
            dropdown.classList.add("show-dropdown");
        } else {
            dropdown.classList.remove("show-dropdown");
        }
    });
    
    // Hide dropdown when clicking outside
    document.addEventListener("click", function (event) {
        let searchBox = document.querySelector(".search-container");
        let dropdown = document.getElementById("dropdownList");
    
        if (!searchBox.contains(event.target)) {
            dropdown.classList.remove("show-dropdown");
        }
    });