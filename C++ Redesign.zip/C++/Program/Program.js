document.getElementById("searchInput").addEventListener("keyup", function () {
    let input = this.value.toLowerCase();
    let dropdown = document.getElementById("dropdownList");
    let items = dropdown.getElementsByTagName("li");

    let hasResults = false;

    for (let i = 0; i < items.length; i++) {
        let text = items[i].textContent.toLowerCase();
        if (text.includes(input)) {
            items[i].style.display = "block";
            hasResults = true;
        } else {
            items[i].style.display = "none";
        }
    }

    // Show dropdown only if there are results
    if (hasResults && input.length > 0) {
        dropdown.classList.add("show-dropdown");
    } else {
        dropdown.classList.remove("show-dropdown");
    }
});

// Hide dropdown when clicking outside
document.addEventListener("click", function (event) {
    let searchBox = document.querySelector(".search-container");
    let dropdown = document.getElementById("dropdownList");

    if (!searchBox.contains(event.target)) {
        dropdown.classList.remove("show-dropdown");
    }
});



    // Run Code Button (Interactive Example)
    const runButton = document.getElementById('run-code');
    const codeInput = document.getElementById('code-input');
    const output = document.getElementById('output');

    runButton.addEventListener('click', () => {
        const code = codeInput.value;

        // Placeholder for actual code execution
        // Replace this with an API call to a C++ compiler
        const placeholderOutput = "Output: Welcome to C++!";
        output.textContent = placeholderOutput;

        // Example: Simulate a delay for API call
        setTimeout(() => {
            output.textContent = "Output: Welcome to C++!";
        }, 1000);
    });
