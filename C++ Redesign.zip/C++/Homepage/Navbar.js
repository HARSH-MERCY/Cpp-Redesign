document.getElementById("searchInput").addEventListener("keyup", function () {
    let input = this.value.toLowerCase();
    let dropdown = document.getElementById("dropdownList");
    let items = dropdown.getElementsByTagName("li");

    let hasResults = false;

    for (let i = 0; i < items.length; i++) {
        let text = items[i].textContent.toLowerCase();
        if (text.includes(input)) {
            items[i].style.display = "block";
            hasResults = true;
        } else {
            items[i].style.display = "none";
        }
    }

    // Show dropdown only if there are results
    if (hasResults && input.length > 0) {
        dropdown.classList.add("show-dropdown");
    } else {
        dropdown.classList.remove("show-dropdown");
    }
});

// Hide dropdown when clicking outside
document.addEventListener("click", function (event) {
    let searchBox = document.querySelector(".search-container");
    let dropdown = document.getElementById("dropdownList");

    if (!searchBox.contains(event.target)) {
        dropdown.classList.remove("show-dropdown");
    }
});




document.addEventListener("DOMContentLoaded", function () {
    const cards = document.querySelectorAll(".card");

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show");
                observer.unobserve(entry.target); // Stop observing once visible
            }
        });
    }, { threshold: 0.2 }); // Trigger when 20% of the card is visible

    cards.forEach(card => {
        observer.observe(card);
    });
});