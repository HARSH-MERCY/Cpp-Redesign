// Sample Thread Data
const threads = [
    { title: "How to use smart pointers in C++?", category: "general", author: "John Doe", date: "2 hours ago", replies: 15 },
    { title: "Best practices for multithreading?", category: "advanced", author: "Jane Smith", date: "3 hours ago", replies: 10 },
    { title: "Understanding C++ Templates", category: "general", author: "Alice Johnson", date: "5 hours ago", replies: 20 },
    { title: "C++ Loops and Control Structures", category: "help", author: "Bob Brown", date: "October 25, 2023", replies: 8 },
    { title: "Templates in C++", category: "advanced", author: "Charlie Davis", date: "October 30, 2023", replies: 12 },
    { title: "Functions in C++", category: "help", author: "David Wilson", date: "November 5, 2023", replies: 7 },
    { title: "STL in C++", category: "advanced", author: "Emily Brown", date: "November 10, 2023", replies: 18 },
    { title: "Memory Management in C++", category: "advanced", author: "Frank Miller", date: "November 15, 2023", replies: 22 },
    { title: "Arrays and Pointers in C++", category: "general", author: "Grace Lee", date: "November 20, 2023", replies: 14 },
];

// Function to render threads
function renderThreads(filteredThreads) {
    const threadGrid = document.getElementById('threadGrid');
    threadGrid.innerHTML = '';
    filteredThreads.forEach(thread => {
        threadGrid.innerHTML += `
            <div class="thread-card">
                <h3>${thread.title}</h3>
                <p>By ${thread.author} | ${thread.date} | ${thread.replies} replies</p>
            </div>
        `;
    });
}

// Category Filter Functionality
const filterButtons = document.querySelectorAll('.filter-button');
filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons
        filterButtons.forEach(btn => btn.classList.remove('active'));
        // Add active class to the clicked button
        button.classList.add('active');

        // Get the selected category
        const category = button.getAttribute('data-category');

        // Filter threads
        const filteredThreads = category === 'all' ? threads : threads.filter(thread => thread.category === category);
        renderThreads(filteredThreads);
    });
});

// Live Search Functionality
const searchInput = document.getElementById('searchInput');
searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredThreads = threads.filter(thread => 
        thread.title.toLowerCase().includes(searchTerm)
    );
    renderThreads(filteredThreads);
});

// Pagination Functionality
const paginationButtons = document.querySelectorAll('.pagination button');
paginationButtons.forEach(button => {
    button.addEventListener('click', () => {
        alert(`Page ${button.textContent} clicked`);
    });
});

// Initial Render
renderThreads(threads);

document.getElementById("searchInput").addEventListener("keyup", function () {
    let input = this.value.toLowerCase();
    let dropdown = document.getElementById("dropdownList");
    let items = dropdown.getElementsByTagName("li");

    let hasResults = false;

    for (let i = 0; i < items.length; i++) {
        let text = items[i].textContent.toLowerCase();
        if (text.includes(input)) {
            items[i].style.display = "block";
            hasResults = true;
        } else {
            items[i].style.display = "none";
        }
    }

    // Show dropdown only if there are results
    if (hasResults && input.length > 0) {
        dropdown.classList.add("show-dropdown");
    } else {
        dropdown.classList.remove("show-dropdown");
    }
});

// Hide dropdown when clicking outside
document.addEventListener("click", function (event) {
    let searchBox = document.querySelector(".search-container");
    let dropdown = document.getElementById("dropdownList");

    if (!searchBox.contains(event.target)) {
        dropdown.classList.remove("show-dropdown");
    }
});